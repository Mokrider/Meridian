# Meridian — parcel tracking platform

A real parcel-tracking system: shipments are created and updated by staff in
the `/admin` dashboard, every status change is written once as a UTC
timestamp, and the public `/track/[trackingNumber]` page converts each event
into the origin's local time, UTC, and the viewer's own local time.

This is the **parcel side only** (per our conversation) — flight booking is
a separate integration project (e.g. via Duffel) and isn't included here.

Stack: Next.js 14 (App Router) + TypeScript + Prisma + PostgreSQL + Tailwind.
No external services required to run it — the only dependency is a Postgres
database.

---

## 1. Open the project in VS Code

1. Unzip `meridian.zip` somewhere on your machine.
2. Open the folder in VS Code: `File → Open Folder…` → select `meridian`.
3. Open a terminal inside VS Code: `` Terminal → New Terminal `` (or `` Ctrl+` ``).
4. Install the recommended extensions if VS Code prompts you (Prisma, Tailwind CSS IntelliSense) — optional but helpful.

## 2. Install dependencies

```bash
npm install
```

## 3. Get a Postgres database

You need a real Postgres instance — this app doesn't ship a database, only
the schema. Two free options that work well with Vercel:

- **[Neon](https://neon.tech)** — click "Create a project", copy the
  connection string it gives you. Neon gives you both a pooled and a direct
  connection string, which map straight to `DATABASE_URL` / `DIRECT_URL`
  below.
- **Vercel Postgres** — from your Vercel project dashboard: `Storage → Create
  Database → Postgres`. It fills in the env vars for you automatically once
  connected (see step 6).

## 4. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and fill in:

- `DATABASE_URL` — your pooled connection string
- `DIRECT_URL` — your direct/unpooled connection string (same value as
  `DATABASE_URL` if your provider only gives you one)
- `ADMIN_PASSWORD` — pick a real password, this gates `/admin`

## 5. Create the database tables

```bash
npx prisma migrate dev --name init
```

This creates the `Shipment` and `TrackingEvent` tables and generates the
Prisma client. Run it again with a new `--name` any time you change
`prisma/schema.prisma`.

## 6. Run it locally

```bash
npm run dev
```

- Public site: [http://localhost:3000](http://localhost:3000)
- Operations dashboard: [http://localhost:3000/admin](http://localhost:3000/admin)
  (log in with the `ADMIN_PASSWORD` you set)

Create a shipment from `/admin/new`, copy its tracking number, and look it
up from the homepage to see the public tracking page.

---

## 7. Deploy to Vercel

### Option A — Vercel's GitHub integration (recommended)

1. Push this project to a GitHub repo:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/meridian.git
   git push -u origin main
   ```
2. Go to [vercel.com/new](https://vercel.com/new), sign in, and click
   **Import** next to your `meridian` repo. Vercel auto-detects Next.js —
   you don't need to change any build settings.
3. Before clicking Deploy, expand **Environment Variables** and add:
   - `DATABASE_URL`
   - `DIRECT_URL`
   - `ADMIN_PASSWORD`
   (same values as your local `.env`, or a fresh production database — see
   note below).
4. Click **Deploy**. Vercel runs `prisma generate && next build`
   automatically (that's what `npm run build` does in `package.json`).
5. Once deployed, run the migration against your **production** database
   once, from your machine, pointing at the production `DATABASE_URL` /
   `DIRECT_URL`:
   ```bash
   npx prisma migrate deploy
   ```

### Option B — Vercel CLI from VS Code's terminal

```bash
npm install -g vercel
vercel login
vercel link          # links this folder to a Vercel project
vercel env add DATABASE_URL production
vercel env add DIRECT_URL production
vercel env add ADMIN_PASSWORD production
vercel --prod        # builds and deploys
```

### Using Vercel Postgres instead of Neon

If you create the database from inside your Vercel project (`Storage →
Create Database → Postgres`), Vercel automatically injects
`POSTGRES_PRISMA_URL` and `POSTGRES_URL_NON_POOLING` into your project's env
vars. Either rename `DATABASE_URL`/`DIRECT_URL` in `prisma/schema.prisma` to
match those names, or simplest: add `DATABASE_URL` and `DIRECT_URL` yourself
in the Vercel dashboard and just paste in the values Vercel generated for
`POSTGRES_PRISMA_URL` and `POSTGRES_URL_NON_POOLING`.

### Every time you change `prisma/schema.prisma`

1. Locally: `npx prisma migrate dev --name <what_changed>` (creates the
   migration file and applies it to your local DB).
2. Commit the new file under `prisma/migrations/` and push.
3. Against production, once: `npx prisma migrate deploy` (with production
   `DATABASE_URL`/`DIRECT_URL` in your shell env, or via `vercel env pull`
   first).

---

## What's here vs. what's next

**Built and working:**
- Shipment creation (sender, recipient, package, service level)
- Append-only tracking-event log with UTC-at-rest timestamps
- Public tracking page with the three-clock (origin / UTC / your local time)
  display on every event
- Admin dashboard: shipment list, create shipment, add tracking events
- Password-gated `/admin`

**Deliberately not built yet** (per our earlier discussion of scope):
- Payments (Stripe/Paystack/PayPal/M-Pesa) — wire in once you decide pricing
- Email/SMS/WhatsApp notifications on status change
- Flight booking (separate project — needs a GDS/aggregator like Duffel)
- Multi-admin accounts with roles (current auth is single shared password —
  fine for one ops person, not for a team)
- Customer accounts / booking history
- Courier/driver GPS integration for the map view

Wiring up notifications is the natural next step once you're ready — the
event-creation code in `app/api/admin/events/route.ts` is the single place
to hook a "send email/SMS on status change" call.
