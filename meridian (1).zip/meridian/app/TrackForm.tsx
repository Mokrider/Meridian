"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function TrackForm() {
  const router = useRouter();
  const [value, setValue] = useState("");
  const [error, setError] = useState<string | null>(null);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = value.trim().toUpperCase();
    if (!trimmed) {
      setError("Enter a tracking number.");
      return;
    }
    setError(null);
    router.push(`/track/${encodeURIComponent(trimmed)}`);
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2">
      <label htmlFor="tracking" className="text-xs uppercase tracking-wider text-ink-muted">
        Track a shipment
      </label>
      <div className="flex gap-2">
        <input
          id="tracking"
          name="tracking"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="MRD-2026-839271"
          className="focus-ring flex-1 rounded-sm border-2 border-ink bg-paper px-4 py-3 font-mono text-sm text-ink placeholder:text-ink-faint"
        />
        <button
          type="submit"
          className="focus-ring rounded-sm bg-mail-red px-5 py-3 text-sm font-medium text-paper hover:bg-ink transition-colors"
        >
          Track
        </button>
      </div>
      {error && <p className="text-sm text-signal-red">{error}</p>}
    </form>
  );
}
