"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { COMMON_TIMEZONES } from "@/lib/timezone";
import {
  SHIPMENT_STATUSES,
  STATUS_LABELS,
  EXCEPTION_REASONS,
  isExceptionStatus,
  type ShipmentStatus,
} from "@/lib/tracking";

export function AddEventForm({
  shipmentId,
  defaultOriginTz,
  defaultDestinationTz,
}: {
  shipmentId: string;
  defaultOriginTz: string;
  defaultDestinationTz: string;
}) {
  const router = useRouter();
  const [status, setStatus] = useState<string>("IN_TRANSIT");
  const [reason, setReason] = useState("");
  const [location, setLocation] = useState("");
  const [locationTimezone, setLocationTimezone] = useState(defaultOriginTz);
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const reasonOptions = isExceptionStatus(status) ? EXCEPTION_REASONS[status as ShipmentStatus] : undefined;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!location.trim()) {
      setError("Location is required.");
      return;
    }
    if (reasonOptions && !reason) {
      setError("A reason is required for this status.");
      return;
    }
    setLoading(true);
    setError(null);

    // Reason (a fixed option) and note (free text) are combined into the
    // single note field the schema already has — no migration needed,
    // and customers see the same combined text on the tracking page.
    const combinedNote = reason ? (note ? `${reason} — ${note}` : reason) : note;

    const res = await fetch("/api/admin/events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        shipmentId,
        status,
        location,
        locationTimezone,
        note: combinedNote,
      }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Something went wrong.");
      return;
    }
    setLocation("");
    setNote("");
    setReason("");
    router.refresh();
  }

  const tzOptions = [
    { label: "Origin default", value: defaultOriginTz },
    { label: "Destination default", value: defaultDestinationTz },
    ...COMMON_TIMEZONES,
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <label className="flex flex-col gap-1">
        <span className="text-xs uppercase tracking-wider text-ink-muted">Status</span>
        <select
          value={status}
          onChange={(e) => {
            setStatus(e.target.value);
            setReason("");
          }}
          className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
        >
          {SHIPMENT_STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </select>
      </label>

      {reasonOptions && (
        <label className="flex flex-col gap-1">
          <span className="text-xs uppercase tracking-wider text-signal-red">Reason (required)</span>
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="focus-ring rounded-sm border-2 border-signal-red bg-paper px-3 py-2 text-sm text-ink"
          >
            <option value="">Select a reason…</option>
            {reasonOptions.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
          <span className="text-[11px] text-ink-faint">
            This is shown to the customer on the tracking page, along with general guidance for this
            status.
          </span>
        </label>
      )}

      <label className="flex flex-col gap-1">
        <span className="text-xs uppercase tracking-wider text-ink-muted">Location</span>
        <input
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="e.g. Nairobi Distribution Center"
          className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
        />
      </label>

      <label className="flex flex-col gap-1">
        <span className="text-xs uppercase tracking-wider text-ink-muted">Location timezone</span>
        <select
          value={locationTimezone}
          onChange={(e) => setLocationTimezone(e.target.value)}
          className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
        >
          {tzOptions.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label} ({o.value})
            </option>
          ))}
        </select>
      </label>

      <label className="flex flex-col gap-1">
        <span className="text-xs uppercase tracking-wider text-ink-muted">
          {reasonOptions ? "Additional detail (optional)" : "Note (optional)"}
        </span>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={2}
          className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
        />
      </label>

      {error && <p className="text-sm text-signal-red">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="focus-ring w-full rounded-sm bg-mail-red px-4 py-2.5 text-sm font-medium text-paper hover:bg-ink disabled:opacity-60 transition-colors"
      >
        {loading ? "Adding…" : "Add event"}
      </button>
    </form>
  );
}
