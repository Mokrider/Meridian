import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { STATUS_LABELS, type ShipmentStatus } from "@/lib/tracking";
import { AddEventForm } from "./AddEventForm";
import { Timeline } from "@/components/Timeline";

export const dynamic = "force-dynamic";

export default async function ShipmentDetailPage({ params }: { params: { id: string } }) {
  const shipment = await prisma.shipment.findUnique({
    where: { id: params.id },
    include: { events: { orderBy: { occurredAtUtc: "asc" } } },
  });

  if (!shipment) notFound();

  return (
    <main className="min-h-screen bg-paper">
      <header className="border-b border-line">
        <div className="max-w-5xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-wider text-mail-red">
              {shipment.trackingNumber}
            </p>
            <h1 className="font-display text-2xl text-ink">
              {STATUS_LABELS[shipment.status as ShipmentStatus] ?? shipment.status}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Link
              href={`/label/${shipment.trackingNumber}`}
              target="_blank"
              className="text-sm text-ink-muted hover:text-ink"
            >
              Waybill ↗
            </Link>
            <Link
              href={`/track/${shipment.trackingNumber}`}
              target="_blank"
              className="text-sm text-mail-red hover:underline"
            >
              View public page ↗
            </Link>
            <Link href="/admin" className="text-sm text-ink-muted hover:text-ink">
              ← Back
            </Link>
          </div>
        </div>
      </header>

      <section className="max-w-5xl mx-auto px-6 py-8 grid lg:grid-cols-[1fr_360px] gap-10">
        <div>
          <h2 className="font-display text-lg text-ink mb-4">Timeline</h2>
          {shipment.events.length === 0 ? (
            <p className="text-ink-faint text-sm">No events yet.</p>
          ) : (
            <Timeline events={shipment.events} currentStatus={shipment.status} />
          )}
        </div>

        <div className="space-y-8">
          <div className="border border-line rounded-sm p-5 bg-paper-soft/60">
            <h3 className="font-display text-lg text-ink mb-3">Route</h3>
            <dl className="text-sm space-y-2 text-ink">
              <Row label="From">
                {shipment.senderName} · {shipment.senderCity}, {shipment.senderCountry}
              </Row>
              <Row label="To">
                {shipment.recipientName} · {shipment.recipientCity}, {shipment.recipientCountry}
              </Row>
              <Row label="Package">
                {shipment.packageType} · {shipment.weightKg} kg
              </Row>
              <Row label="Service">{shipment.serviceLevel}</Row>
            </dl>
          </div>

          <div className="border border-line rounded-sm p-5 bg-paper-soft/60">
            <h3 className="font-display text-lg text-ink mb-3">Add tracking event</h3>
            <AddEventForm
              shipmentId={shipment.id}
              defaultOriginTz={shipment.originTimezone}
              defaultDestinationTz={shipment.destinationTimezone}
            />
          </div>
        </div>
      </section>
    </main>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-ink-muted">{label}</dt>
      <dd className="text-right">{children}</dd>
    </div>
  );
}
