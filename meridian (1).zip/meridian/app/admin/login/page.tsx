"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    setLoading(false);
    if (!res.ok) {
      setError("Incorrect password.");
      return;
    }
    router.push(params.get("next") || "/admin");
    router.refresh();
  }

  return (
    <main className="min-h-screen bg-paper flex items-center justify-center px-6">
      <form onSubmit={handleSubmit} className="w-full max-w-sm">
        <p className="font-mono text-xs uppercase tracking-wider text-mail-red mb-2">
          Operations
        </p>
        <h1 className="font-display text-2xl text-ink mb-6">Sign in</h1>
        <input
          type="password"
          autoFocus
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Admin password"
          className="focus-ring w-full rounded-sm border-2 border-ink bg-paper px-4 py-3 text-sm text-ink mb-3"
        />
        {error && <p className="text-sm text-signal-red mb-3">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="focus-ring w-full rounded-sm bg-mail-red px-4 py-3 text-sm font-medium text-paper hover:bg-ink disabled:opacity-60 transition-colors"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </main>
  );
}
