"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { COMMON_TIMEZONES } from "@/lib/timezone";
import { PACKAGE_TYPES, SERVICE_LEVELS } from "@/lib/tracking";

const initial = {
  senderName: "",
  senderPhone: "",
  senderEmail: "",
  senderAddress: "",
  senderCountry: "",
  senderCity: "",
  originTimezone: "Africa/Nairobi",
  recipientName: "",
  recipientPhone: "",
  recipientEmail: "",
  recipientAddress: "",
  recipientCountry: "",
  recipientCity: "",
  destinationTimezone: "America/New_York",
  packageType: "PACKAGE",
  description: "",
  weightKg: "",
  lengthCm: "",
  widthCm: "",
  heightCm: "",
  declaredValue: "",
  serviceLevel: "STANDARD",
  estimatedDelivery: "",
};

export function NewShipmentForm() {
  const router = useRouter();
  const [form, setForm] = useState(initial);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function set<K extends keyof typeof initial>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/admin/shipments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Something went wrong.");
      return;
    }
    const data = await res.json();
    router.push(`/admin/${data.shipment.id}`);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-10">
      <FormSection title="Sender">
        <Field label="Full name" value={form.senderName} onChange={(v) => set("senderName", v)} required />
        <Field label="Phone" value={form.senderPhone} onChange={(v) => set("senderPhone", v)} required />
        <Field label="Email" value={form.senderEmail} onChange={(v) => set("senderEmail", v)} type="email" />
        <Field label="Address" value={form.senderAddress} onChange={(v) => set("senderAddress", v)} required full />
        <Field label="City" value={form.senderCity} onChange={(v) => set("senderCity", v)} required />
        <Field label="Country" value={form.senderCountry} onChange={(v) => set("senderCountry", v)} required />
        <TzField label="Origin timezone" value={form.originTimezone} onChange={(v) => set("originTimezone", v)} />
      </FormSection>

      <FormSection title="Recipient">
        <Field label="Full name" value={form.recipientName} onChange={(v) => set("recipientName", v)} required />
        <Field label="Phone" value={form.recipientPhone} onChange={(v) => set("recipientPhone", v)} required />
        <Field label="Email" value={form.recipientEmail} onChange={(v) => set("recipientEmail", v)} type="email" />
        <Field label="Address" value={form.recipientAddress} onChange={(v) => set("recipientAddress", v)} required full />
        <Field label="City" value={form.recipientCity} onChange={(v) => set("recipientCity", v)} required />
        <Field label="Country" value={form.recipientCountry} onChange={(v) => set("recipientCountry", v)} required />
        <TzField
          label="Destination timezone"
          value={form.destinationTimezone}
          onChange={(v) => set("destinationTimezone", v)}
        />
      </FormSection>

      <FormSection title="Package">
        <SelectField
          label="Type"
          value={form.packageType}
          onChange={(v) => set("packageType", v)}
          options={PACKAGE_TYPES.map((t) => ({ label: t, value: t }))}
        />
        <SelectField
          label="Service level"
          value={form.serviceLevel}
          onChange={(v) => set("serviceLevel", v)}
          options={SERVICE_LEVELS.map((s) => ({ label: s, value: s }))}
        />
        <Field label="Weight (kg)" value={form.weightKg} onChange={(v) => set("weightKg", v)} type="number" required />
        <Field label="Declared value" value={form.declaredValue} onChange={(v) => set("declaredValue", v)} type="number" />
        <Field label="Length (cm)" value={form.lengthCm} onChange={(v) => set("lengthCm", v)} type="number" />
        <Field label="Width (cm)" value={form.widthCm} onChange={(v) => set("widthCm", v)} type="number" />
        <Field label="Height (cm)" value={form.heightCm} onChange={(v) => set("heightCm", v)} type="number" />
        <Field
          label="Estimated delivery"
          value={form.estimatedDelivery}
          onChange={(v) => set("estimatedDelivery", v)}
          type="date"
        />
        <Field label="Description" value={form.description} onChange={(v) => set("description", v)} full />
      </FormSection>

      {error && <p className="text-sm text-signal-red">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="focus-ring rounded-md bg-mail-red px-6 py-3 text-sm font-medium text-paper hover:bg-ink disabled:opacity-60 transition-colors"
      >
        {loading ? "Creating…" : "Create shipment"}
      </button>
    </form>
  );
}

function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <fieldset>
      <legend className="font-display text-xl text-ink mb-4">{title}</legend>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{children}</div>
    </fieldset>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
  full = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  full?: boolean;
}) {
  return (
    <label className={`flex flex-col gap-1 ${full ? "sm:col-span-2" : ""}`}>
      <span className="text-xs uppercase tracking-wider text-ink-muted">
        {label}
        {required && <span className="text-mail-red"> *</span>}
      </span>
      <input
        type={type}
        value={value}
        required={required}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring rounded-md border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
      />
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { label: string; value: string }[];
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-xs uppercase tracking-wider text-ink-muted">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="focus-ring rounded-md border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function TzField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return <SelectField label={label} value={value} onChange={onChange} options={COMMON_TIMEZONES} />;
}
