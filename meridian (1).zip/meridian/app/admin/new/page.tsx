import Link from "next/link";
import { NewShipmentForm } from "./NewShipmentForm";

export default function NewShipmentPage() {
  return (
    <main className="min-h-screen bg-paper">
      <header className="border-b border-line">
        <div className="max-w-3xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-wider text-mail-red">Operations</p>
            <h1 className="font-display text-2xl text-ink">New shipment</h1>
          </div>
          <Link href="/admin" className="text-sm text-ink-muted hover:text-ink">
            ← Back
          </Link>
        </div>
      </header>
      <section className="max-w-3xl mx-auto px-6 py-8">
        <NewShipmentForm />
      </section>
    </main>
  );
}
