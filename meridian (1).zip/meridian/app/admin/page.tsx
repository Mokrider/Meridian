import Link from "next/link";
import { prisma } from "@/lib/db";
import { STATUS_LABELS, SHIPMENT_STATUSES, isExceptionStatus, type ShipmentStatus } from "@/lib/tracking";
import { AdminNav } from "@/components/AdminNav";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 20;

export default async function AdminDashboard({
  searchParams,
}: {
  searchParams: { q?: string; status?: string; page?: string };
}) {
  const q = (searchParams.q || "").trim();
  const status = searchParams.status || "";
  const page = Math.max(1, Number(searchParams.page) || 1);

  const where: any = {};
  if (status) where.status = status;
  if (q) {
    where.OR = [
      { trackingNumber: { contains: q, mode: "insensitive" } },
      { senderName: { contains: q, mode: "insensitive" } },
      { recipientName: { contains: q, mode: "insensitive" } },
      { senderCity: { contains: q, mode: "insensitive" } },
      { recipientCity: { contains: q, mode: "insensitive" } },
    ];
  }

  const [shipments, matchingCount, totalCount, statusCounts] = await Promise.all([
    prisma.shipment.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.shipment.count({ where }),
    prisma.shipment.count(),
    prisma.shipment.groupBy({ by: ["status"], _count: true }),
  ]);

  const delivered = statusCounts.find((s) => s.status === "DELIVERED")?._count ?? 0;
  const active =
    totalCount -
    delivered -
    (statusCounts.find((s) => s.status === "CANCELLED")?._count ?? 0) -
    (statusCounts.find((s) => s.status === "RETURNED")?._count ?? 0);

  const totalPages = Math.max(1, Math.ceil(matchingCount / PAGE_SIZE));
  const hasFilters = Boolean(q || status);

  function pageHref(targetPage: number) {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (status) params.set("status", status);
    params.set("page", String(targetPage));
    return `/admin?${params.toString()}`;
  }

  return (
    <main className="min-h-screen bg-paper">
      <AdminNav active="dashboard" />

      <section className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-3 gap-4 mb-10 max-w-lg">
          <Stat label="Total shipments" value={totalCount} />
          <Stat label="Active" value={active} />
          <Stat label="Delivered" value={delivered} />
        </div>

        <form action="/admin" method="GET" className="flex flex-wrap items-end gap-3 mb-6">
          <label className="flex flex-col gap-1 flex-1 min-w-[220px]">
            <span className="text-xs uppercase tracking-wider text-ink-muted">Search</span>
            <input
              type="text"
              name="q"
              defaultValue={q}
              placeholder="Tracking #, name, or city"
              className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-xs uppercase tracking-wider text-ink-muted">Status</span>
            <select
              name="status"
              defaultValue={status}
              className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
            >
              <option value="">All statuses</option>
              {SHIPMENT_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {STATUS_LABELS[s]}
                </option>
              ))}
            </select>
          </label>
          <button
            type="submit"
            className="focus-ring rounded-sm bg-ink px-5 py-2 text-sm font-medium text-paper hover:bg-mail-blue transition-colors"
          >
            Filter
          </button>
          {hasFilters && (
            <Link href="/admin" className="text-sm text-ink-muted hover:text-mail-red px-1 py-2">
              Clear
            </Link>
          )}
        </form>

        <div className="border border-line rounded-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-paper-soft text-left text-ink-muted">
                <th className="px-4 py-3 font-medium">Tracking #</th>
                <th className="px-4 py-3 font-medium">Route</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Created</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {shipments.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-ink-faint">
                    {hasFilters ? (
                      <>
                        No shipments match those filters.{" "}
                        <Link href="/admin" className="text-mail-red hover:underline">
                          Clear filters
                        </Link>
                        .
                      </>
                    ) : (
                      <>
                        No shipments yet.{" "}
                        <Link href="/admin/new" className="text-mail-red hover:underline">
                          Create the first one
                        </Link>
                        .
                      </>
                    )}
                  </td>
                </tr>
              )}
              {shipments.map((s) => (
                <tr key={s.id} className="border-t border-line text-ink">
                  <td className="px-4 py-3 font-mono text-xs">{s.trackingNumber}</td>
                  <td className="px-4 py-3">
                    {s.senderCity} → {s.recipientCity}
                  </td>
                  <td className="px-4 py-3">
                    <StatusPill status={s.status as ShipmentStatus} />
                  </td>
                  <td className="px-4 py-3 text-ink-muted">
                    {new Intl.DateTimeFormat("en-US", { dateStyle: "medium" }).format(s.createdAt)}
                  </td>
                  <td className="px-4 py-3 text-right space-x-3">
                    <Link href={`/label/${s.trackingNumber}`} className="text-ink-muted hover:underline">
                      Waybill
                    </Link>
                    <Link href={`/admin/${s.id}`} className="text-mail-red hover:underline">
                      Manage →
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {matchingCount > 0 && (
          <div className="flex items-center justify-between mt-4 text-sm text-ink-muted">
            <p>
              Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, matchingCount)} of{" "}
              {matchingCount}
            </p>
            <div className="flex items-center gap-2">
              {page > 1 ? (
                <Link href={pageHref(page - 1)} className="hover:text-mail-red">
                  ← Prev
                </Link>
              ) : (
                <span className="text-ink-faint">← Prev</span>
              )}
              <span className="font-mono text-xs">
                {page} / {totalPages}
              </span>
              {page < totalPages ? (
                <Link href={pageHref(page + 1)} className="hover:text-mail-red">
                  Next →
                </Link>
              ) : (
                <span className="text-ink-faint">Next →</span>
              )}
            </div>
          </div>
        )}
      </section>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="border border-line rounded-sm p-4 bg-paper-soft/60">
      <p className="text-xs text-ink-muted">{label}</p>
      <p className="font-display text-3xl text-ink mt-1">{value}</p>
    </div>
  );
}

function StatusPill({ status }: { status: ShipmentStatus }) {
  const isProblem = isExceptionStatus(status);
  const isDone = status === "DELIVERED";
  const color = isProblem ? "text-signal-red" : isDone ? "text-signal-green" : "text-mail-blue";
  return <span className={`font-mono text-xs ${color}`}>{STATUS_LABELS[status]}</span>;
}
