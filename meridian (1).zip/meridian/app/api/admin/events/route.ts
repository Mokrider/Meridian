import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { SHIPMENT_STATUSES, type ShipmentStatus } from "@/lib/tracking";
import { sendStatusUpdate } from "@/lib/email";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { shipmentId, status, location, locationTimezone, note, occurredAtUtc } = body;

  if (!shipmentId || !status || !location || !locationTimezone) {
    return NextResponse.json(
      { error: "shipmentId, status, location and locationTimezone are required" },
      { status: 400 }
    );
  }

  if (!SHIPMENT_STATUSES.includes(status)) {
    return NextResponse.json({ error: `Unknown status: ${status}` }, { status: 400 });
  }

  const shipment = await prisma.shipment.findUnique({ where: { id: shipmentId } });
  if (!shipment) {
    return NextResponse.json({ error: "Shipment not found" }, { status: 404 });
  }

  const [event] = await prisma.$transaction([
    prisma.trackingEvent.create({
      data: {
        shipmentId,
        status,
        location,
        locationTimezone,
        note: note || null,
        occurredAtUtc: occurredAtUtc ? new Date(occurredAtUtc) : new Date(),
        createdBy: "admin",
      },
    }),
    prisma.shipment.update({
      where: { id: shipmentId },
      data: { status },
    }),
  ]);

  // BOOKED is skipped here — that email already went out when the shipment
  // was created. Every other status change gets its own notification.
  if (status !== "BOOKED") {
    sendStatusUpdate(shipment, status as ShipmentStatus, location).catch((err) =>
      console.error("[email] status update failed", err)
    );
  }

  return NextResponse.json({ event }, { status: 201 });
}
