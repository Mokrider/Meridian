import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { generateTrackingNumber } from "@/lib/tracking";
import { sendBookingConfirmation } from "@/lib/email";

export async function GET() {
  const shipments = await prisma.shipment.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    select: {
      id: true,
      trackingNumber: true,
      status: true,
      senderCity: true,
      senderCountry: true,
      recipientCity: true,
      recipientCountry: true,
      createdAt: true,
    },
  });
  return NextResponse.json({ shipments });
}

const REQUIRED_FIELDS = [
  "senderName",
  "senderPhone",
  "senderAddress",
  "senderCountry",
  "senderCity",
  "originTimezone",
  "recipientName",
  "recipientPhone",
  "recipientAddress",
  "recipientCountry",
  "recipientCity",
  "destinationTimezone",
  "packageType",
  "weightKg",
] as const;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body) {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const missing = REQUIRED_FIELDS.filter((field) => {
    const value = body[field];
    return value === undefined || value === null || value === "";
  });
  if (missing.length > 0) {
    return NextResponse.json(
      { error: `Missing required fields: ${missing.join(", ")}` },
      { status: 400 }
    );
  }

  const weightKg = Number(body.weightKg);
  if (Number.isNaN(weightKg) || weightKg <= 0) {
    return NextResponse.json({ error: "weightKg must be a positive number" }, { status: 400 });
  }

  // Retry on the (unlikely) chance of a tracking-number collision.
  let shipment;
  for (let attempt = 0; attempt < 5; attempt++) {
    const trackingNumber = generateTrackingNumber();
    try {
      shipment = await prisma.shipment.create({
        data: {
          trackingNumber,
          senderName: body.senderName,
          senderPhone: body.senderPhone,
          senderEmail: body.senderEmail || null,
          senderAddress: body.senderAddress,
          senderCountry: body.senderCountry,
          senderCity: body.senderCity,
          originTimezone: body.originTimezone,
          recipientName: body.recipientName,
          recipientPhone: body.recipientPhone,
          recipientEmail: body.recipientEmail || null,
          recipientAddress: body.recipientAddress,
          recipientCountry: body.recipientCountry,
          recipientCity: body.recipientCity,
          destinationTimezone: body.destinationTimezone,
          packageType: body.packageType,
          description: body.description || null,
          weightKg,
          lengthCm: body.lengthCm ? Number(body.lengthCm) : null,
          widthCm: body.widthCm ? Number(body.widthCm) : null,
          heightCm: body.heightCm ? Number(body.heightCm) : null,
          declaredValue: body.declaredValue ? Number(body.declaredValue) : null,
          serviceLevel: body.serviceLevel || "STANDARD",
          status: "BOOKED",
          estimatedDelivery: body.estimatedDelivery ? new Date(body.estimatedDelivery) : null,
          events: {
            create: {
              status: "BOOKED",
              location: `${body.senderCity}, ${body.senderCountry}`,
              locationTimezone: body.originTimezone,
              note: "Shipment created.",
              createdBy: "admin",
            },
          },
        },
      });
      break;
    } catch (err: any) {
      if (err?.code === "P2002") continue; // unique constraint collision, retry
      return NextResponse.json({ error: "Failed to create shipment" }, { status: 500 });
    }
  }

  if (!shipment) {
    return NextResponse.json(
      { error: "Could not generate a unique tracking number, try again" },
      { status: 500 }
    );
  }

  // Fire-and-forget: a slow or failed email should never hold up (or fail)
  // shipment creation itself. Errors are logged inside sendBookingConfirmation.
  sendBookingConfirmation(shipment).catch((err) =>
    console.error("[email] booking confirmation failed", err)
  );

  return NextResponse.json({ shipment }, { status: 201 });
}
