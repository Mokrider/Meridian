import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(
  _req: NextRequest,
  { params }: { params: { trackingNumber: string } }
) {
  const trackingNumber = params.trackingNumber.trim().toUpperCase();

  const shipment = await prisma.shipment.findUnique({
    where: { trackingNumber },
    include: { events: { orderBy: { occurredAtUtc: "asc" } } },
  });

  if (!shipment) {
    return NextResponse.json({ error: "Shipment not found" }, { status: 404 });
  }

  // Public endpoint: only return what a recipient/sender needs to see, not
  // full contact details for the other party.
  return NextResponse.json({
    trackingNumber: shipment.trackingNumber,
    status: shipment.status,
    originCity: shipment.senderCity,
    originCountry: shipment.senderCountry,
    destinationCity: shipment.recipientCity,
    destinationCountry: shipment.recipientCountry,
    serviceLevel: shipment.serviceLevel,
    estimatedDelivery: shipment.estimatedDelivery,
    createdAt: shipment.createdAt,
    events: shipment.events,
  });
}
