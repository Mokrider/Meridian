import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { ShippingLabel } from "@/components/ShippingLabel";
import { PrintLabelButton } from "@/components/PrintLabelButton";

export const dynamic = "force-dynamic";

export default async function LabelPage({
  params,
}: {
  params: { trackingNumber: string };
}) {
  const shipment = await prisma.shipment.findUnique({
    where: { trackingNumber: params.trackingNumber.toUpperCase() },
  });

  if (!shipment) notFound();

  return (
    <main className="min-h-screen bg-paper bg-grid">
      <header className="no-print max-w-3xl mx-auto px-6 py-6 flex items-center justify-between">
        <Link href="/" className="font-display text-2xl text-ink">
          Meridian
        </Link>
        <div className="flex items-center gap-5 text-sm">
          <Link
            href={`/track/${shipment.trackingNumber}`}
            className="text-ink-muted hover:text-mail-red"
          >
            ← Back to tracking
          </Link>
          <Link href="/admin" className="text-ink-muted hover:text-mail-red">
            Operations
          </Link>
        </div>
      </header>

      <section className="max-w-3xl mx-auto px-6 pb-24">
        <ShippingLabel shipment={shipment} />
        <div className="mt-6 flex items-center justify-between">
          <p className="no-print text-xs text-ink-faint max-w-sm">
            This is the same waybill your recipient can see — nothing on it is generated until a real
            shipment exists.
          </p>
          <PrintLabelButton />
        </div>
      </section>
    </main>
  );
}
