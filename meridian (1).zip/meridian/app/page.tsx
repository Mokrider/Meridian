import Image from "next/image";
import Link from "next/link";
import { TrackForm } from "./TrackForm";
import { ShippingLabel } from "@/components/ShippingLabel";
import { CostEstimator } from "@/components/CostEstimator";

const SAMPLE_SHIPMENT = {
  trackingNumber: "MRD-2026-118204",
  status: "IN_TRANSIT",
  serviceLevel: "EXPRESS",
  packageType: "PACKAGE",
  weightKg: 3.4,
  senderName: "A. Wanjiru",
  senderCity: "Nairobi",
  senderCountry: "Kenya",
  recipientName: "J. Alaoui",
  recipientCity: "Marseille",
  recipientCountry: "France",
  createdAt: new Date("2026-08-11"),
  estimatedDelivery: new Date("2026-08-19"),
};

export default function HomePage() {
  return (
    <main className="min-h-screen bg-paper">
      <div className="airmail-stripe" />

      {/* Photo hero band — dark scrim over the image so light text stays
          legible; everything below this band goes back to the plain
          paper theme. */}
      <div className="relative isolate overflow-hidden">
        <Image
          src="/hero-plane.jpg"
          alt=""
          fill
          priority
          className="object-cover object-center -z-10"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/90 via-ink/80 to-ink/95 -z-10" />

        <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between relative z-10">
          <span className="font-display text-2xl tracking-tight text-paper">Meridian</span>
          <nav className="flex items-center gap-6 text-sm text-paper/80">
            <a href="#track" className="hover:text-paper transition-colors">
              Track
            </a>
            <Link href="/admin" className="hover:text-paper transition-colors">
              Operations
            </Link>
          </nav>
        </header>

        <section className="relative z-10 max-w-6xl mx-auto px-6 pt-12 pb-20 grid lg:grid-cols-[1fr_auto] gap-12 items-start">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-mail-red">
              Prime meridian · 0° longitude · every clock agrees
            </p>
            <h1 className="font-display font-semibold text-5xl sm:text-6xl leading-[0.95] mt-4 text-paper max-w-xl">
              A parcel service that never fakes a location.
            </h1>
            <p className="text-paper/75 mt-6 max-w-md text-lg">
              Every scan, hub arrival, and handoff is recorded once in UTC and shown back to you — and
              your recipient — in local time, correctly, even across daylight saving.
            </p>

            <div id="track" className="mt-10 max-w-md">
              <TrackForm />
            </div>
          </div>

          <div className="hidden lg:block w-[380px] pt-2">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-paper/60 mb-3 text-right">
              Every booking gets one of these
            </p>
            <ShippingLabel shipment={SAMPLE_SHIPMENT} sample />
          </div>
        </section>
      </div>

      <section className="max-w-6xl mx-auto px-6 py-16 grid lg:grid-cols-[1fr_380px] gap-10 items-start">
        <div className="grid sm:grid-cols-3 gap-4">
          <FeatureCard
            title="One source of truth"
            body="Every event is written once, in UTC, the instant it happens. Nothing is re-derived or guessed after the fact."
          />
          <FeatureCard
            title="Local by default"
            body="Your browser's timezone is detected automatically — no settings to configure, no confusion at 11:58pm."
          />
          <FeatureCard
            title="Honest status"
            body="If we don't know exactly where a parcel is, we say 'last known location' — never a fabricated position."
          />
        </div>
        <CostEstimator />
      </section>

      <footer className="border-t border-line">
        <div className="max-w-6xl mx-auto px-6 py-8 text-sm text-ink-faint flex justify-between">
          <span>Meridian</span>
          <span className="font-mono text-xs">built on Next.js</span>
        </div>
      </footer>
    </main>
  );
}

function FeatureCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="border border-line rounded-sm p-5 bg-paper-soft/60">
      <h3 className="font-display text-lg text-ink">{title}</h3>
      <p className="text-sm text-ink-muted mt-2 leading-relaxed">{body}</p>
    </div>
  );
}
