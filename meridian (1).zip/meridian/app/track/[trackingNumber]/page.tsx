import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { STATUS_LABELS, EXCEPTION_GUIDANCE, isExceptionStatus, type ShipmentStatus } from "@/lib/tracking";
import { Timeline } from "@/components/Timeline";

export const dynamic = "force-dynamic";

async function getShipment(trackingNumber: string) {
  return prisma.shipment.findUnique({
    where: { trackingNumber: trackingNumber.toUpperCase() },
    include: { events: { orderBy: { occurredAtUtc: "asc" } } },
  });
}

export default async function TrackPage({
  params,
}: {
  params: { trackingNumber: string };
}) {
  const shipment = await getShipment(params.trackingNumber);

  if (!shipment) {
    return (
      <main className="min-h-screen bg-paper flex items-center justify-center px-6">
        <div className="text-center max-w-sm">
          <p className="font-mono text-xs uppercase tracking-wider text-mail-red mb-2">
            Not found
          </p>
          <h1 className="font-display text-2xl text-ink mb-3">
            We couldn't find that tracking number
          </h1>
          <p className="text-ink-muted text-sm mb-6">
            Double check{" "}
            <span className="font-mono text-ink">
              {params.trackingNumber.toUpperCase()}
            </span>{" "}
            against your confirmation email, or try again.
          </p>
          <Link href="/" className="text-mail-red text-sm hover:underline">
            ← Back to Meridian
          </Link>
        </div>
      </main>
    );
  }

  const isProblem = isExceptionStatus(shipment.status);
  const guidance = isProblem ? EXCEPTION_GUIDANCE[shipment.status as ShipmentStatus] : undefined;

  return (
    <main className="min-h-screen bg-paper bg-grid">
      <header className="max-w-3xl mx-auto px-6 py-6 flex items-center justify-between">
        <Link href="/" className="font-display text-xl text-ink">
          Meridian
        </Link>
        <div className="flex items-center gap-5 text-sm">
          <Link href="/" className="text-ink-muted hover:text-mail-red">
            Track another
          </Link>
          <Link href="/admin" className="text-ink-muted hover:text-mail-red">
            Operations
          </Link>
        </div>
      </header>

      <section className="max-w-3xl mx-auto px-6 pb-24">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <p className="font-mono text-xs uppercase tracking-wider text-mail-red">
              {shipment.trackingNumber}
            </p>
            <div className="flex items-center gap-3 mt-2">
              <h1 className="font-display text-3xl text-ink">
                {STATUS_LABELS[shipment.status as ShipmentStatus] ?? shipment.status}
              </h1>
              <span
                className={`h-2.5 w-2.5 rounded-full ${
                  isProblem ? "bg-signal-red" : shipment.status === "DELIVERED" ? "bg-signal-green" : "bg-mail-blue"
                }`}
              />
            </div>
            <p className="text-ink-muted mt-2">
              {shipment.senderCity}, {shipment.senderCountry} → {shipment.recipientCity},{" "}
              {shipment.recipientCountry}
            </p>
            {shipment.estimatedDelivery && (
              <p className="text-sm text-ink-faint mt-1">
                Estimated arrival:{" "}
                {new Intl.DateTimeFormat("en-US", { dateStyle: "long" }).format(
                  shipment.estimatedDelivery
                )}
              </p>
            )}
          </div>

          <Link
            href={`/label/${shipment.trackingNumber}`}
            className="focus-ring shrink-0 rounded-sm border-2 border-ink px-4 py-2 text-sm font-medium text-ink hover:bg-ink hover:text-paper transition-colors"
          >
            View waybill →
          </Link>
        </div>

        {guidance && (
          <div className="mt-8 border-2 border-signal-red rounded-sm bg-signal-red/5 p-5">
            <p className="font-display text-lg text-ink">{guidance.title}</p>
            <p className="text-sm text-ink-muted mt-1.5 leading-relaxed">{guidance.body}</p>
          </div>
        )}

        <div className="mt-12 border-t border-line pt-10">
          {shipment.events.length === 0 ? (
            <p className="text-ink-faint text-sm">No tracking events yet.</p>
          ) : (
            <Timeline events={shipment.events} currentStatus={shipment.status} />
          )}
        </div>
      </section>
    </main>
  );
}
