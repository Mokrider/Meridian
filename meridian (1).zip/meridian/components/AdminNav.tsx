import Link from "next/link";
import { LogoutButton } from "@/app/admin/LogoutButton";

/**
 * One shared nav for every admin screen, so there's always a direct path
 * to the dashboard, a new shipment, and public tracking — instead of each
 * page inventing its own ad-hoc set of back-links.
 */
export function AdminNav({ active }: { active: "dashboard" | "new" | "detail" }) {
  return (
    <header className="border-b border-line">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/admin" className="font-display text-xl text-ink">
            Meridian
          </Link>
          <nav className="flex items-center gap-5 text-sm">
            <Link
              href="/admin"
              className={active === "dashboard" ? "text-mail-red" : "text-ink-muted hover:text-ink"}
            >
              Dashboard
            </Link>
            <Link
              href="/admin/new"
              className={active === "new" ? "text-mail-red" : "text-ink-muted hover:text-ink"}
            >
              New shipment
            </Link>
            <a href="/#track" className="text-ink-muted hover:text-ink">
              Track (public)
            </a>
          </nav>
        </div>
        <LogoutButton />
      </div>
    </header>
  );
}
