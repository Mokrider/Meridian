"use client";

import { useEffect, useState } from "react";
import { formatInTimeZone, formatUtc, shortZoneLabel } from "@/lib/timezone";

/**
 * The platform's signature element: every tracking event shows the same
 * instant through three lenses — where it happened, UTC (the source of
 * truth), and the viewer's own device timezone. Nothing here is guessed;
 * occurredAtUtc is the only value stored, everything else is derived.
 */
export function ClockStrip({
  occurredAtUtc,
  eventTimezone,
  eventLocationLabel,
}: {
  occurredAtUtc: string; // ISO string
  eventTimezone: string;
  eventLocationLabel: string;
}) {
  const [viewerTz, setViewerTz] = useState<string | null>(null);
  const date = new Date(occurredAtUtc);

  useEffect(() => {
    setViewerTz(Intl.DateTimeFormat().resolvedOptions().timeZone);
  }, []);

  const rows = [
    {
      label: eventLocationLabel,
      value: formatInTimeZone(date, eventTimezone),
      sub: shortZoneLabel(date, eventTimezone),
    },
    {
      label: "Coordinated Universal Time",
      value: formatUtc(date),
      sub: "UTC",
    },
  ];

  if (viewerTz && viewerTz !== eventTimezone) {
    rows.push({
      label: "Your local time",
      value: formatInTimeZone(date, viewerTz),
      sub: shortZoneLabel(date, viewerTz),
    });
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
      {rows.map((row) => (
        <div
          key={row.label}
          className="rounded-sm border border-line bg-paper-soft/60 px-3 py-2"
        >
          <div className="text-[10px] uppercase tracking-wider text-mail-red/80">
            {row.label}
          </div>
          <div className="font-mono text-sm text-ink mt-0.5">{row.value}</div>
          <div className="text-[10px] text-ink-faint mt-0.5">{row.sub}</div>
        </div>
      ))}
    </div>
  );
}
