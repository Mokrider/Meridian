"use client";

import { useState } from "react";
import { estimateShippingCost } from "@/lib/pricing";
import { SERVICE_LEVELS, type ServiceLevel } from "@/lib/tracking";

const LEVEL_LABELS: Record<ServiceLevel, string> = {
  STANDARD: "Standard",
  EXPRESS: "Express",
  PRIORITY: "Priority",
};

export function CostEstimator() {
  const [weightKg, setWeightKg] = useState(2);
  const [serviceLevel, setServiceLevel] = useState<ServiceLevel>("STANDARD");
  const [domestic, setDomestic] = useState(true);

  const estimate = estimateShippingCost({ weightKg, serviceLevel, domestic });

  return (
    <div className="border-2 border-ink rounded-sm bg-paper p-6">
      <p className="font-mono text-xs uppercase tracking-wider text-mail-red mb-1">Estimate cost</p>
      <h3 className="font-display text-xl text-ink mb-5">What would this cost to ship?</h3>

      <div className="grid sm:grid-cols-3 gap-4 mb-5">
        <label className="flex flex-col gap-1">
          <span className="text-xs uppercase tracking-wider text-ink-muted">Weight (kg)</span>
          <input
            type="number"
            min={0.1}
            step={0.1}
            value={weightKg}
            onChange={(e) => setWeightKg(Math.max(0, Number(e.target.value) || 0))}
            className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
          />
        </label>

        <label className="flex flex-col gap-1">
          <span className="text-xs uppercase tracking-wider text-ink-muted">Service</span>
          <select
            value={serviceLevel}
            onChange={(e) => setServiceLevel(e.target.value as ServiceLevel)}
            className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
          >
            {SERVICE_LEVELS.map((level) => (
              <option key={level} value={level}>
                {LEVEL_LABELS[level]}
              </option>
            ))}
          </select>
        </label>

        <label className="flex flex-col gap-1">
          <span className="text-xs uppercase tracking-wider text-ink-muted">Route</span>
          <select
            value={domestic ? "domestic" : "international"}
            onChange={(e) => setDomestic(e.target.value === "domestic")}
            className="focus-ring rounded-sm border-2 border-ink bg-paper px-3 py-2 text-sm text-ink"
          >
            <option value="domestic">Same country</option>
            <option value="international">International</option>
          </select>
        </label>
      </div>

      <div className="flex items-end justify-between border-t border-line pt-4">
        <div className="text-xs text-ink-faint font-mono">
          ${estimate.base.toFixed(2)} base + ${estimate.weightCost.toFixed(2)} ({weightKg}kg)
        </div>
        <div className="text-right">
          <p className="font-mono text-[10px] uppercase tracking-wider text-ink-faint">Estimated</p>
          <p className="font-display text-3xl text-ink leading-none">${estimate.total.toFixed(2)}</p>
        </div>
      </div>
      <p className="text-[11px] text-ink-faint mt-3">
        An estimate, not a quote — the real price is set when a shipment is booked.
      </p>
    </div>
  );
}
