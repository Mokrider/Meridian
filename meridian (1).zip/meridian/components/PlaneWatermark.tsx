/**
 * A large, faint line-art plane behind the hero — kept in the same
 * thin-stroke, navy-ink style as the rest of the airmail motif (the
 * PlaneMark icon on the waybill, the route line between cities) rather
 * than a stock photo, so it reads as part of the system instead of
 * decoration bolted on top of it.
 */
export function PlaneWatermark({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 600 600"
      className={`pointer-events-none select-none text-ink/[0.09] ${className}`}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      aria-hidden
    >
      <g transform="rotate(28 300 300)">
        <path
          d="M300 40 L300 300 L520 400 L520 440 L300 370 L300 480 L370 530 L370 555 L300 530 L230 555 L230 530 L300 480 L300 370 L80 440 L80 400 L300 300 Z"
          fill="currentColor"
          stroke="none"
        />
        <path d="M300 40 L300 560" strokeDasharray="4 8" />
      </g>
    </svg>
  );
}
