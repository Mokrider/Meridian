"use client";

export function PrintLabelButton() {
  return (
    <button
      onClick={() => window.print()}
      className="focus-ring no-print rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-paper hover:bg-mail-blue transition-colors"
    >
      Print / save as PDF
    </button>
  );
}
