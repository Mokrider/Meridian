import { STATUS_LABELS, type ShipmentStatus } from "@/lib/tracking";

export type LabelShipment = {
  trackingNumber: string;
  status: string;
  serviceLevel: string;
  packageType: string;
  weightKg: number;
  senderName: string;
  senderCity: string;
  senderCountry: string;
  recipientName: string;
  recipientCity: string;
  recipientCountry: string;
  createdAt: Date | string;
  estimatedDelivery?: Date | string | null;
};

/**
 * The real deliverable behind "generate a ticket after payment": a waybill
 * tied to an actual Shipment row. Every field here is read straight off
 * the record — nothing on this label is invented, which is the same
 * honesty rule the tracking page follows for status/location.
 *
 * `sample` renders clearly-marked placeholder data for the homepage
 * preview, so it can never be mistaken for a real shipment record.
 */
export function ShippingLabel({
  shipment,
  sample = false,
}: {
  shipment: LabelShipment;
  sample?: boolean;
}) {
  const created = new Date(shipment.createdAt);
  const eta = shipment.estimatedDelivery ? new Date(shipment.estimatedDelivery) : null;

  return (
    <div className="relative isolate bg-paper border-2 border-ink rounded-sm shadow-[6px_6px_0_0_#182339] overflow-hidden">
      {/* Faint photo texture — screen only. Printers skip background
          images unless the user manually opts in, and even then a full
          photo behind a printed document wastes ink and hurts
          legibility, so this is hidden for print/PDF output via the
          print:hidden utility. */}
      <div
        className="absolute inset-0 -z-10 bg-cover bg-center opacity-[0.07] print:hidden"
        style={{ backgroundImage: "url('/hero-plane.jpg')" }}
        aria-hidden
      />
      <div className="airmail-stripe" />

      {sample && (
        <div className="absolute top-6 right-[-38px] rotate-45 bg-mail-red text-paper text-[10px] font-mono tracking-[0.3em] uppercase px-10 py-1 z-10">
          Sample
        </div>
      )}

      <div className="grid grid-cols-[1fr_auto] divide-x-2 divide-dashed divide-ink/30">
        {/* Main stub */}
        <div className="p-6 sm:p-8">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-mail-red">
                Meridian · Air Waybill
              </p>
              <p className="font-display text-3xl sm:text-4xl tracking-tight text-ink mt-1">
                {shipment.trackingNumber}
              </p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-mono text-[10px] uppercase tracking-wider text-ink-faint">Service</p>
              <p className="font-display text-lg text-mail-blue leading-none">{shipment.serviceLevel}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 mt-6">
            <RouteEnd city={shipment.senderCity} country={shipment.senderCountry} label="From" />
            <div className="flex-1 border-t-2 border-dashed border-ink/30 relative top-[1px]" />
            <PlaneMark />
            <div className="flex-1 border-t-2 border-dashed border-ink/30 relative top-[1px]" />
            <RouteEnd
              city={shipment.recipientCity}
              country={shipment.recipientCountry}
              label="To"
              align="right"
            />
          </div>

          <div className="grid grid-cols-2 gap-x-4 gap-y-5 mt-8 text-sm">
            <LabelField label="Sender" value={shipment.senderName} />
            <LabelField label="Recipient" value={shipment.recipientName} />
            <LabelField label="Contents" value={shipment.packageType} />
            <LabelField label="Weight" value={`${shipment.weightKg} kg`} />
          </div>

          <p className="font-mono text-[10px] text-ink-faint mt-8 leading-relaxed">
            This waybill reflects the shipment record on file as of{" "}
            {new Intl.DateTimeFormat("en-US", { dateStyle: "medium" }).format(created)}. It is not proof
            of customs clearance or delivery.
          </p>
        </div>

        {/* Tear-off stub */}
        <div className="p-5 flex flex-col justify-between items-center w-40 sm:w-48 bg-paper-soft">
          <div className="text-center">
            <p className="font-mono text-[9px] uppercase tracking-wider text-ink-faint">Status</p>
            <p className="font-display text-base text-ink leading-tight mt-1">
              {STATUS_LABELS[shipment.status as ShipmentStatus] ?? shipment.status}
            </p>
          </div>

          <Barcode value={shipment.trackingNumber} />

          <div className="text-center">
            <p className="font-mono text-[9px] uppercase tracking-wider text-ink-faint">
              {eta ? "Est. arrival" : "Booked"}
            </p>
            <p className="font-mono text-xs text-ink mt-1">
              {new Intl.DateTimeFormat("en-US", { dateStyle: "medium" }).format(eta ?? created)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function RouteEnd({
  city,
  country,
  label,
  align = "left",
}: {
  city: string;
  country: string;
  label: string;
  align?: "left" | "right";
}) {
  return (
    <div className={align === "right" ? "text-right" : ""}>
      <p className="font-mono text-[9px] uppercase tracking-wider text-ink-faint">{label}</p>
      <p className="font-display text-xl text-ink leading-none mt-0.5">{city}</p>
      <p className="text-[11px] text-ink-muted">{country}</p>
    </div>
  );
}

function LabelField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="font-mono text-[9px] uppercase tracking-wider text-ink-faint">{label}</p>
      <p className="text-ink mt-0.5">{value}</p>
    </div>
  );
}

function PlaneMark() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="w-4 h-4 text-mail-blue shrink-0 rotate-90"
      fill="currentColor"
      aria-hidden
    >
      <path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2.5 2v1.5L12 21l4.5 1.5V21L14 19v-5.5l7 2.5z" />
    </svg>
  );
}

/**
 * A deterministic pseudo-barcode: bar widths derive from the tracking
 * number's own characters, so the same shipment always renders the same
 * pattern. Decorative (not scannable) — the tracking number underneath it
 * is the real identifier.
 */
function Barcode({ value }: { value: string }) {
  const bars = value
    .split("")
    .map((ch) => (ch.charCodeAt(0) % 3) + 1);

  return (
    <div className="flex items-end gap-[2px] h-12">
      {bars.map((w, i) => (
        <div key={i} className="bg-ink" style={{ width: `${w}px`, height: "100%" }} />
      ))}
    </div>
  );
}
