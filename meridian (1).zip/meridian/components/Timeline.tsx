import { STATUS_LABELS, TIMELINE_ORDER, isExceptionStatus, type ShipmentStatus } from "@/lib/tracking";
import { ClockStrip } from "./ClockStrip";

type Event = {
  id: string;
  status: string;
  location: string;
  locationTimezone: string;
  occurredAtUtc: Date | string;
  note: string | null;
};

export function Timeline({ events, currentStatus }: { events: Event[]; currentStatus: string }) {
  const sorted = [...events].sort(
    (a, b) => new Date(a.occurredAtUtc).getTime() - new Date(b.occurredAtUtc).getTime()
  );

  const isTerminal = currentStatus === "DELIVERED";
  const isProblem = isExceptionStatus(currentStatus);

  return (
    <div className="space-y-0">
      {sorted.map((event, idx) => {
        const isLast = idx === sorted.length - 1;
        const isCurrent = isLast;
        const dotColor = isProblem && isCurrent ? "bg-signal-red" : isCurrent ? "bg-mail-red" : "bg-signal-green";

        return (
          <div key={event.id} className="relative pl-8 pb-8 last:pb-0">
            {!isLast && (
              <span className="absolute left-[9px] top-3 bottom-0 w-px bg-line" aria-hidden />
            )}
            <span
              className={`absolute left-0 top-1.5 h-[19px] w-[19px] rounded-full border-2 border-paper ${dotColor} ${
                isCurrent ? "ring-2 ring-mail-red/30" : ""
              }`}
              aria-hidden
            />
            <div>
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-display text-lg text-ink">
                  {STATUS_LABELS[event.status as ShipmentStatus] ?? event.status}
                </h3>
              </div>
              <p className="text-sm text-ink-muted mt-0.5">{event.location}</p>
              {event.note && <p className="text-sm text-ink-muted mt-1 italic">{event.note}</p>}
              <ClockStrip
                occurredAtUtc={new Date(event.occurredAtUtc).toISOString()}
                eventTimezone={event.locationTimezone}
                eventLocationLabel={event.location}
              />
            </div>
          </div>
        );
      })}

      {!isTerminal && !isProblem && (
        <UpcomingStops currentStatus={currentStatus as ShipmentStatus} />
      )}
    </div>
  );
}

function UpcomingStops({ currentStatus }: { currentStatus: ShipmentStatus }) {
  const currentIdx = TIMELINE_ORDER.indexOf(currentStatus);
  const upcoming = currentIdx >= 0 ? TIMELINE_ORDER.slice(currentIdx + 1) : [];

  if (upcoming.length === 0) return null;

  return (
    <>
      {upcoming.map((status) => (
        <div key={status} className="relative pl-8 pb-8 last:pb-0">
          <span
            className="absolute left-[9px] top-3 bottom-0 w-px bg-line last:hidden"
            aria-hidden
          />
          <span
            className="absolute left-0 top-1.5 h-[19px] w-[19px] rounded-full border-2 border-line bg-paper-soft"
            aria-hidden
          />
          <h3 className="font-display text-lg text-ink-faint">{STATUS_LABELS[status]}</h3>
        </div>
      ))}
    </>
  );
}
