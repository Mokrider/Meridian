import { cookies } from "next/headers";

const COOKIE_NAME = "meridian_admin";

/**
 * MVP auth: a single admin password set via env var, no user table.
 * The session cookie simply holds the password itself, set httpOnly +
 * secure so client JS and network eavesdroppers can't read it. Middleware
 * (which runs on the Edge runtime, where Node's `crypto` module is not
 * available) compares it directly against ADMIN_PASSWORD — no HMAC needed
 * for a single shared password. Swap for real auth (Clerk/Auth.js) once
 * you have multiple admins or need per-user audit trails.
 */
export function isValidAdminPassword(password: string): boolean {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return false;
  return password === expected;
}

export function adminCookieOptions() {
  return {
    name: COOKIE_NAME,
    value: process.env.ADMIN_PASSWORD ?? "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: 60 * 60 * 12, // 12 hours
  };
}

export function isAdminSession(): boolean {
  const cookie = cookies().get(COOKIE_NAME);
  const expected = process.env.ADMIN_PASSWORD;
  if (!cookie || !expected) return false;
  return cookie.value === expected;
}

export const ADMIN_COOKIE_NAME = COOKIE_NAME;
