import { STATUS_LABELS, type ShipmentStatus } from "./tracking";

const RESEND_API_URL = "https://api.resend.com/emails";
const FROM_ADDRESS = "Meridian <onboarding@resend.dev>";

type ShipmentForEmail = {
  trackingNumber: string;
  senderName: string;
  senderCity: string;
  senderCountry: string;
  senderEmail?: string | null;
  recipientName: string;
  recipientCity: string;
  recipientCountry: string;
  recipientEmail?: string | null;
  serviceLevel: string;
  weightKg: number;
  packageType: string;
};

function appUrl() {
  return process.env.APP_URL || "http://localhost:3000";
}

/**
 * Sends via Resend's REST API directly (no SDK dependency to install).
 * Never throws — a failed email should never take down a shipment
 * creation or status update, so callers fire this and move on. Errors
 * are logged server-side for now; a future pass could record a
 * "notification failed" note on the shipment instead of just logging.
 */
async function sendEmail({ to, subject, html }: { to: string; subject: string; html: string }) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.warn("[email] RESEND_API_KEY not set — skipping send:", subject, "to", to);
    return;
  }

  try {
    const res = await fetch(RESEND_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: FROM_ADDRESS, to, subject, html }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error("[email] Resend API error", res.status, text);
    }
  } catch (err) {
    console.error("[email] send failed", err);
  }
}

function emailShell(bodyHtml: string) {
  return `
  <div style="background:#FBF9F2;padding:32px 16px;font-family:-apple-system,Helvetica,Arial,sans-serif;">
    <div style="max-width:520px;margin:0 auto;background:#FFFFFF;border:2px solid #182339;border-radius:2px;overflow:hidden;">
      <div style="height:8px;background:repeating-linear-gradient(-45deg,#D6293E 0,#D6293E 10px,transparent 10px,transparent 14px,#1F4E8C 14px,#1F4E8C 24px,transparent 24px,transparent 28px);"></div>
      <div style="padding:28px 32px;">
        <p style="font-family:monospace;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#D6293E;margin:0 0 4px;">Meridian</p>
        ${bodyHtml}
      </div>
      <div style="border-top:1px solid #DDD6BE;padding:16px 32px;">
        <p style="font-family:monospace;font-size:11px;color:#8D93A0;margin:0;">This is an automated message from Meridian shipment tracking.</p>
      </div>
    </div>
  </div>`;
}

function routeLine(s: ShipmentForEmail) {
  return `${s.senderCity}, ${s.senderCountry} &rarr; ${s.recipientCity}, ${s.recipientCountry}`;
}

/**
 * The email version of the "real ticket" the homepage promises: sent only
 * once a shipment row actually exists, links straight to the waybill and
 * tracking page for that real record — nothing in the email is invented.
 */
export async function sendBookingConfirmation(shipment: ShipmentForEmail) {
  const trackUrl = `${appUrl()}/track/${shipment.trackingNumber}`;
  const labelUrl = `${appUrl()}/label/${shipment.trackingNumber}`;

  const senderHtml = emailShell(`
    <h1 style="font-size:22px;color:#182339;margin:12px 0 8px;">Shipment booked</h1>
    <p style="color:#5B6577;font-size:14px;line-height:1.5;">
      Your shipment to <strong>${shipment.recipientName}</strong> has been booked.
    </p>
    <p style="font-family:monospace;font-size:20px;color:#182339;margin:20px 0 4px;">${shipment.trackingNumber}</p>
    <p style="color:#5B6577;font-size:13px;margin:0 0 20px;">${routeLine(shipment)} &middot; ${shipment.serviceLevel}</p>
    <a href="${trackUrl}" style="display:inline-block;background:#D6293E;color:#FBF9F2;text-decoration:none;padding:10px 20px;border-radius:2px;font-size:14px;margin-right:8px;">Track shipment</a>
    <a href="${labelUrl}" style="display:inline-block;border:2px solid #182339;color:#182339;text-decoration:none;padding:8px 18px;border-radius:2px;font-size:14px;">View waybill</a>
  `);

  const recipientHtml = emailShell(`
    <h1 style="font-size:22px;color:#182339;margin:12px 0 8px;">A parcel is on its way to you</h1>
    <p style="color:#5B6577;font-size:14px;line-height:1.5;">
      <strong>${shipment.senderName}</strong> has sent you a shipment via Meridian.
    </p>
    <p style="font-family:monospace;font-size:20px;color:#182339;margin:20px 0 4px;">${shipment.trackingNumber}</p>
    <p style="color:#5B6577;font-size:13px;margin:0 0 20px;">${routeLine(shipment)} &middot; ${shipment.serviceLevel}</p>
    <a href="${trackUrl}" style="display:inline-block;background:#D6293E;color:#FBF9F2;text-decoration:none;padding:10px 20px;border-radius:2px;font-size:14px;">Track your parcel</a>
  `);

  const jobs = [];
  if (shipment.senderEmail) {
    jobs.push(
      sendEmail({ to: shipment.senderEmail, subject: `Booked — ${shipment.trackingNumber}`, html: senderHtml })
    );
  }
  if (shipment.recipientEmail) {
    jobs.push(
      sendEmail({
        to: shipment.recipientEmail,
        subject: `A parcel is on its way — ${shipment.trackingNumber}`,
        html: recipientHtml,
      })
    );
  }
  await Promise.all(jobs);
}

export async function sendStatusUpdate(
  shipment: ShipmentForEmail,
  newStatus: ShipmentStatus,
  location: string
) {
  const trackUrl = `${appUrl()}/track/${shipment.trackingNumber}`;
  const label = STATUS_LABELS[newStatus] ?? newStatus;

  const html = emailShell(`
    <h1 style="font-size:22px;color:#182339;margin:12px 0 8px;">${label}</h1>
    <p style="color:#5B6577;font-size:14px;line-height:1.5;">
      Shipment <strong style="font-family:monospace;">${shipment.trackingNumber}</strong> is now
      <strong>${label.toLowerCase()}</strong> at ${location}.
    </p>
    <a href="${trackUrl}" style="display:inline-block;background:#1F4E8C;color:#FBF9F2;text-decoration:none;padding:10px 20px;border-radius:2px;font-size:14px;margin-top:12px;">View full timeline</a>
  `);

  const jobs = [];
  if (shipment.senderEmail) {
    jobs.push(
      sendEmail({ to: shipment.senderEmail, subject: `${label} — ${shipment.trackingNumber}`, html })
    );
  }
  if (shipment.recipientEmail) {
    jobs.push(
      sendEmail({ to: shipment.recipientEmail, subject: `${label} — ${shipment.trackingNumber}`, html })
    );
  }
  await Promise.all(jobs);
}
