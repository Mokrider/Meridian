import type { ServiceLevel } from "./tracking";

/**
 * A transparent, auditable formula rather than a black-box "quote" —
 * consistent with the rest of the app never showing a number it can't
 * explain. Rates are illustrative placeholders; swap RATES for real
 * figures whenever the business has them.
 */
const RATES: Record<ServiceLevel, { base: number; perKgDomestic: number; perKgIntl: number }> = {
  STANDARD: { base: 8, perKgDomestic: 2.5, perKgIntl: 5 },
  EXPRESS: { base: 15, perKgDomestic: 4, perKgIntl: 8 },
  PRIORITY: { base: 25, perKgDomestic: 6, perKgIntl: 12 },
};

export type CostEstimate = {
  base: number;
  weightCost: number;
  total: number;
  currency: "USD";
};

export function estimateShippingCost({
  weightKg,
  serviceLevel,
  domestic,
}: {
  weightKg: number;
  serviceLevel: ServiceLevel;
  domestic: boolean;
}): CostEstimate {
  const rate = RATES[serviceLevel];
  const perKg = domestic ? rate.perKgDomestic : rate.perKgIntl;
  const weightCost = Math.round(weightKg * perKg * 100) / 100;
  const total = Math.round((rate.base + weightCost) * 100) / 100;

  return { base: rate.base, weightCost, total, currency: "USD" };
}
