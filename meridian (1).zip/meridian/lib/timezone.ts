/**
 * All event timestamps are stored in the database as UTC (occurredAtUtc).
 * This module converts a UTC instant into any IANA timezone for display,
 * without ever mutating what's stored. Native Intl.DateTimeFormat handles
 * DST correctly per-zone, which is why we store IANA identifiers
 * (e.g. "Africa/Nairobi") rather than fixed offsets (e.g. "UTC+3").
 */

export function formatInTimeZone(
  date: Date,
  timeZone: string,
  opts: Intl.DateTimeFormatOptions = {}
): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      timeZone,
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
      month: "short",
      day: "numeric",
      year: "numeric",
      ...opts,
    }).format(date);
  } catch {
    // Falls back to UTC if an invalid/unknown IANA zone ever slips through.
    return new Intl.DateTimeFormat("en-US", {
      timeZone: "UTC",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
      month: "short",
      day: "numeric",
      year: "numeric",
      ...opts,
    }).format(date);
  }
}

export function shortZoneLabel(date: Date, timeZone: string): string {
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone,
      timeZoneName: "short",
    }).formatToParts(date);
    return parts.find((p) => p.type === "timeZoneName")?.value ?? timeZone;
  } catch {
    return timeZone;
  }
}

export function formatUtc(date: Date): string {
  return (
    new Intl.DateTimeFormat("en-GB", {
      timeZone: "UTC",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(date) + " UTC"
  );
}

/** Common IANA timezones grouped for a select input. Not exhaustive — extend as you add countries. */
export const COMMON_TIMEZONES: { label: string; value: string }[] = [
  { label: "Nairobi (EAT)", value: "Africa/Nairobi" },
  { label: "Lagos (WAT)", value: "Africa/Lagos" },
  { label: "Cairo (EET)", value: "Africa/Cairo" },
  { label: "Johannesburg (SAST)", value: "Africa/Johannesburg" },
  { label: "London (GMT/BST)", value: "Europe/London" },
  { label: "Paris (CET)", value: "Europe/Paris" },
  { label: "New York (ET)", value: "America/New_York" },
  { label: "Chicago (CT)", value: "America/Chicago" },
  { label: "Los Angeles (PT)", value: "America/Los_Angeles" },
  { label: "Dubai (GST)", value: "Asia/Dubai" },
  { label: "Mumbai (IST)", value: "Asia/Kolkata" },
  { label: "Tokyo (JST)", value: "Asia/Tokyo" },
  { label: "Shanghai (CST)", value: "Asia/Shanghai" },
  { label: "Sydney (AET)", value: "Australia/Sydney" },
];
