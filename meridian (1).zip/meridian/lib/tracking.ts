export const SHIPMENT_STATUSES = [
  "BOOKED",
  "PICKED_UP",
  "RECEIVED_AT_HUB",
  "PROCESSING",
  "CUSTOMS_CLEARANCE",
  "CUSTOMS_CLEARED",
  "DEPARTED_ORIGIN",
  "IN_TRANSIT",
  "ARRIVED_DESTINATION",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
  "DELIVERY_ATTEMPTED",
  "HELD",
  "RETURNED",
  "CANCELLED",
] as const;

export type ShipmentStatus = (typeof SHIPMENT_STATUSES)[number];

export const STATUS_LABELS: Record<ShipmentStatus, string> = {
  BOOKED: "Booked",
  PICKED_UP: "Picked Up",
  RECEIVED_AT_HUB: "Received at Hub",
  PROCESSING: "Processing",
  CUSTOMS_CLEARANCE: "Customs Clearance",
  CUSTOMS_CLEARED: "Customs Cleared",
  DEPARTED_ORIGIN: "Departed Origin",
  IN_TRANSIT: "In Transit",
  ARRIVED_DESTINATION: "Arrived at Destination",
  OUT_FOR_DELIVERY: "Out for Delivery",
  DELIVERED: "Delivered",
  DELIVERY_ATTEMPTED: "Delivery Attempted",
  HELD: "Held",
  RETURNED: "Returned to Sender",
  CANCELLED: "Cancelled",
};

// Statuses that count as "in progress" for the visual timeline, in canonical order.
export const TIMELINE_ORDER: ShipmentStatus[] = [
  "BOOKED",
  "PICKED_UP",
  "RECEIVED_AT_HUB",
  "PROCESSING",
  "CUSTOMS_CLEARANCE",
  "DEPARTED_ORIGIN",
  "IN_TRANSIT",
  "ARRIVED_DESTINATION",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
];

export const SERVICE_LEVELS = ["STANDARD", "EXPRESS", "PRIORITY"] as const;
export type ServiceLevel = (typeof SERVICE_LEVELS)[number];

export const PACKAGE_TYPES = ["DOCUMENT", "PACKAGE", "CARGO"] as const;
export type PackageType = (typeof PACKAGE_TYPES)[number];

/**
 * Generates a tracking number like MRD-2026-839271.
 * Uniqueness is enforced at the database level (unique constraint) with a retry
 * loop at the call site, since a random collision — while unlikely — is possible.
 */
export function generateTrackingNumber(date = new Date()): string {
  const year = date.getUTCFullYear();
  const digits = Math.floor(100000 + Math.random() * 900000); // 6 digits
  return `MRD-${year}-${digits}`;
}

export function isValidTrackingNumber(value: string): boolean {
  return /^MRD-\d{4}-\d{6}$/.test(value.trim().toUpperCase());
}

/**
 * Statuses that mean something went wrong rather than normal progress.
 * Centralized here so every screen (timeline dot color, admin table pill,
 * customer callout) agrees on the same list instead of each maintaining
 * its own copy.
 */
export const EXCEPTION_STATUSES: ShipmentStatus[] = [
  "HELD",
  "DELIVERY_ATTEMPTED",
  "RETURNED",
  "CANCELLED",
];

export function isExceptionStatus(status: string): status is (typeof EXCEPTION_STATUSES)[number] {
  return (EXCEPTION_STATUSES as string[]).includes(status);
}

/**
 * Structured reason options admin picks from when logging an exception
 * event — kept as plain strings written into the event's free-text note
 * (no schema change needed) rather than a separate reason-code column.
 */
export const EXCEPTION_REASONS: Partial<Record<ShipmentStatus, string[]>> = {
  HELD: [
    "Customs documentation required",
    "Incomplete or incorrect address",
    "Payment or customs duty outstanding",
    "Awaiting customer instructions",
    "Held for security screening",
  ],
  DELIVERY_ATTEMPTED: [
    "Recipient not available",
    "Address could not be located",
    "Business closed at time of delivery",
    "Access restricted (gate, building, etc.)",
  ],
  RETURNED: [
    "Refused by recipient",
    "Undeliverable after repeated attempts",
    "Rejected at customs",
    "Incorrect or incomplete address",
  ],
  CANCELLED: [
    "Cancelled by sender",
    "Cancelled by Meridian",
    "Duplicate booking",
    "Prohibited item identified",
  ],
};

/**
 * What a customer sees on the tracking page when a shipment hits an
 * exception status — plain-language explanation plus what happens next,
 * so a red status dot isn't the only signal they get.
 */
export const EXCEPTION_GUIDANCE: Partial<Record<ShipmentStatus, { title: string; body: string }>> = {
  HELD: {
    title: "This shipment needs something before it can continue",
    body: "Check the note on the most recent event below for the specific reason. If it's not resolved within a few days, contact support with your tracking number.",
  },
  DELIVERY_ATTEMPTED: {
    title: "Delivery was attempted but not completed",
    body: "A redelivery will usually be attempted automatically. If you'd like to arrange a specific time or a different address, contact support with your tracking number.",
  },
  RETURNED: {
    title: "This shipment is being returned to the sender",
    body: "It will not continue to the original destination. See the note below for the reason, and contact support if this doesn't look right.",
  },
  CANCELLED: {
    title: "This shipment was cancelled",
    body: "It will not be delivered. See the note below for the reason, or contact support with your tracking number if you have questions.",
  },
};
