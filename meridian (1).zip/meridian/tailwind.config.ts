import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: {
          DEFAULT: "#FBF9F2",
          soft: "#F1EBD6",
          dim: "#E7DFC4",
        },
        ink: {
          DEFAULT: "#182339",
          muted: "#5B6577",
          faint: "#8D93A0",
        },
        line: "#DDD6BE",
        mail: {
          red: "#D6293E",
          blue: "#1F4E8C",
        },
        stamp: "#C1872C",
        signal: {
          green: "#2E8B57",
          amber: "#C1872C",
          red: "#C8393F",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "grid-lines":
          "linear-gradient(rgba(24,35,57,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(24,35,57,0.05) 1px, transparent 1px)",
        "airmail-stripe":
          "repeating-linear-gradient(-45deg, #D6293E 0, #D6293E 14px, #FBF9F2 14px, #FBF9F2 20px, #1F4E8C 20px, #1F4E8C 34px, #FBF9F2 34px, #FBF9F2 40px)",
      },
    },
  },
  plugins: [],
};

export default config;
